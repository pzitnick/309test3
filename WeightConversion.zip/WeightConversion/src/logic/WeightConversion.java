package logic;

public class WeightConversion {

    public double KilosToPounds (double kilos){
        
        return (kilos / 0.454);
    }
    
public double PoundsToKilos (double pounds){
        
        return (pounds * 0.454);
    }
}
